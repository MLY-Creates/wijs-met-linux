## 1. Het Linux verhaal

Tijdens de jaren '80 en '90 had Microsoft een harde grip op de markt van computersoftware. In 1991 draaide 90% van de computers op Microsoft DOS of op de toen nieuwe Microsoft Windows. DOS en Windows zijn wat ze "closed source" noemen, waarbij niemand naast Microsoft echt weet hoe de code erachter werkt.

Dat moest anders, en op 17 september 1991 bracht Linus Torvalds de eerste versie van Linux op de markt. Linux is niet alleen vat werkt, en met genoeg technische kennis, zelf code toe kan voegen om Linux verder te helpen. Omdat het "open source" is, kan iedereen zien hoe het werkt, en met genoeg technische kennis, zelf code toe kan voegen om Linux verder te helpen.

Dat "closed en open source" is wat het verschil in filosofie tussen Windows en Linux brengt. Omdat Microsoft volledige controle over Windows heeft, ondernemen ze acties die vaak anti-consument zijn, om meer winst te maken. Met Linux kan dat niet, omdat het van de gebruikers, voor de gebruikers is. En er dus geen grote coorperatie achterzit.